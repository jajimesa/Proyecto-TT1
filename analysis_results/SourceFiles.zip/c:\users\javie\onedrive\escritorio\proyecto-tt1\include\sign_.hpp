//$Header$
//------------------------------------------------------------------------------
// sign_
//------------------------------------------------------------------------------
/**
 * @file sign_.hpp
 * @author Javier Jiménez Santana
 * @date 21/04/2024
 */
//------------------------------------------------------------------------------

#ifndef _SIGN_
#define _SIGN_

#include <cmath>

double sign_(double a, double b);
double sign(double a);

#endif